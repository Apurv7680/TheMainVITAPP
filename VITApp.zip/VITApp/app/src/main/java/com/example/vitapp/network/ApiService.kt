package com.example.vitapp.network

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Header

interface ApiService {

    @GET("events/")
    suspend fun getEvents(): Response<List<Event>>

    @POST("events/")
    suspend fun addEvent(
        @Header("Authorization") authHeader: String,
        @Body event: Event
    ): Response<Event>

    @POST("login/") // change this path if your Django endpoint is different
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

}

data class LoginRequest(
    val username: String,
    val password: String
)

data class LoginResponse(
    val refresh: String,  // or access/refresh if using JWT
    val access: String,   // student / club_president
    val role: String
)
