package com.example.vitapp

import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import com.example.vitapp.network.Event
import com.example.vitapp.network.LoginRequest
import com.example.vitapp.network.RetrofitClient
import kotlinx.coroutines.launch
import org.json.JSONObject

// Function to extract role from JWT token
fun extractRoleFromToken(token: String): String? {
    return try {
        val parts = token.split(".")
        if (parts.size < 2) return null

        val payload = parts[1]
        val decodedBytes = Base64.decode(payload, Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        val json = String(decodedBytes, Charsets.UTF_8)

        // Log or print to debug
        println("JWT Payload JSON: $json")

        val jsonObject = JSONObject(json)

        // Try different keys depending on your backend naming
        val role = jsonObject.optString("role", null) ?: jsonObject.optString("user_role", null)

        println("Extracted role: $role")

        role
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppContent()
        }
    }
}

@Composable
fun LoginScreen(
    username: String,
    onUsernameChange: (String) -> Unit,
    password: String,
    onPasswordChange: (String) -> Unit,
    loginResult: String,
    onLogin: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "VIT Login", style = MaterialTheme.typography.h4)

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = username,
            onValueChange = onUsernameChange,
            label = { Text("Username or Email") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = password,
            onValueChange = onPasswordChange,
            label = { Text("Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onLogin,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }

        Spacer(modifier = Modifier.height(20.dp))

        if (loginResult.isNotBlank()) {
            Text(
                text = loginResult,
                color = if (loginResult.startsWith("Error") || loginResult.startsWith("Login failed"))
                    MaterialTheme.colors.error else MaterialTheme.colors.onBackground
            )
        }
    }
}

@Composable
fun EventsScreen(events: List<Event>, userRole: String?, onEventClick: (Event) -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Welcome! Role: ${userRole ?: "Unknown"}", style = MaterialTheme.typography.subtitle1)
        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "Events", style = MaterialTheme.typography.h5)
        Spacer(modifier = Modifier.height(10.dp))

        if (events.isEmpty()) {
            Text("No events available")
        } else {
            events.forEach { event ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clickable { onEventClick(event) },
                    elevation = 8.dp,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp)) {
                        val imageUrl = event.image.replace("127.0.0.1", "10.0.2.2")
                        Image(
                            painter = rememberAsyncImagePainter(imageUrl),
                            contentDescription = event.title,
                            modifier = Modifier
                                .size(80.dp)
                                .padding(end = 16.dp),
                            contentScale = ContentScale.Crop
                        )

                        Column {
                            Text(text = event.title, style = MaterialTheme.typography.subtitle1, color = Color.Black)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = event.description,
                                maxLines = 2,
                                style = MaterialTheme.typography.body2,
                                color = Color.DarkGray
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(text = event.date, style = MaterialTheme.typography.caption)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EventDetailScreen(event: Event, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Button(onClick = onBack) {
            Text("Back")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = event.title, style = MaterialTheme.typography.h4)
        Spacer(modifier = Modifier.height(8.dp))

        Image(
            painter = rememberAsyncImagePainter(event.image),
            contentDescription = event.title,
            modifier = Modifier
                .fillMaxWidth()
                .height(250.dp),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(16.dp))

        Text(text = event.description, style = MaterialTheme.typography.body1)
        Spacer(modifier = Modifier.height(8.dp))

        Text(text = "Date: ${event.date}", style = MaterialTheme.typography.caption)
    }
}

@Composable
fun AddEventDialog(
    authToken: String?,
    onDismiss: () -> Unit,
    onEventAdded: (Event) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add New Event") },
        text = {
            Column {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") }
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") }
                )
                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("Date (YYYY-MM-DD)") }
                )
                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = { Text("Image URL") }
                )
                if (errorMessage != null) {
                    Text(errorMessage!!, color = MaterialTheme.colors.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || description.isBlank() || date.isBlank() || imageUrl.isBlank()) {
                        errorMessage = "Please fill all fields"
                        return@Button
                    }
                    errorMessage = null
                    coroutineScope.launch {
                        try {
                            if (authToken == null) {
                                errorMessage = "Not authorized"
                                return@launch
                            }
                            val event = Event(
                                id = 0,  // ID is generated by backend
                                title = title,
                                description = description,
                                date = date,
                                image = imageUrl
                            )
                            val response = RetrofitClient.apiService.addEvent("Bearer $authToken", event)
                            if (response.isSuccessful) {
                                val addedEvent = response.body()
                                if (addedEvent != null) {
                                    onEventAdded(addedEvent)
                                } else {
                                    errorMessage = "Failed to get added event from server"
                                }
                            } else {
                                errorMessage = "Error adding event: ${response.code()}"
                            }
                        } catch (e: Exception) {
                            errorMessage = "Exception: ${e.localizedMessage}"
                        }
                    }
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AppContent() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loginResult by remember { mutableStateOf("") }
    var isLoggedIn by remember { mutableStateOf(false) }
    var userRole by remember { mutableStateOf<String?>(null) }
    var authToken by remember { mutableStateOf<String?>(null) }
    var showAddEventDialog by remember { mutableStateOf(false) }
    var events by remember { mutableStateOf<List<Event>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    var selectedEvent by remember { mutableStateOf<Event?>(null) }

    val coroutineScope = rememberCoroutineScope()

    if (!isLoggedIn) {
        LoginScreen(
            username = username,
            onUsernameChange = { username = it },
            password = password,
            onPasswordChange = { password = it },
            loginResult = loginResult,
            onLogin = {
                coroutineScope.launch {
                    loginResult = ""
                    try {
                        val response = RetrofitClient.apiService.login(LoginRequest(username, password))
                        if (response.isSuccessful) {
                            val loginResponse = response.body()
                            authToken = loginResponse?.access
                            userRole = loginResponse?.role
                            isLoggedIn = true
                            loginResult = "Login successful!"
                            password = "" // Clear password after login
                        } else {
                            loginResult = "Login failed: ${response.code()}"
                        }
                    } catch (e: Exception) {
                        loginResult = "Error: ${e.localizedMessage}"
                    }
                }
            }
        )
    } else {
        LaunchedEffect(isLoggedIn) {
            try {
                val response = RetrofitClient.apiService.getEvents()
                if (response.isSuccessful) {
                    events = response.body() ?: emptyList()
                    error = null
                } else {
                    error = "Error: ${response.code()}"
                }
            } catch (e: Exception) {
                error = e.localizedMessage
            }
        }

        if (error != null) {
            Text(
                text = "Error loading events: $error",
                color = MaterialTheme.colors.error,
                modifier = Modifier.padding(16.dp)
            )
        } else {
            if (selectedEvent == null) {
                Column {
                    // Debug text to show role value
                    Text(
                        text = "Logged in as role: '${userRole ?: "unknown"}'",
                        color = Color.Blue,
                        modifier = Modifier.padding(16.dp)
                    )

                    EventsScreen(
                        events = events,
                        userRole = userRole,
                        onEventClick = { event -> selectedEvent = event }
                    )

                    // Show "Add Event" button only if role is exactly "club_president" (case-insensitive)
                    if (userRole?.trim()?.lowercase() == "club_president") {
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { showAddEventDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp)
                        ) {
                            Text("Add New Event")
                        }
                    }
                }
            } else {
                EventDetailScreen(
                    event = selectedEvent!!,
                    onBack = { selectedEvent = null }
                )
            }
        }

        if (showAddEventDialog) {
            AddEventDialog(
                authToken = authToken,
                onDismiss = { showAddEventDialog = false },
                onEventAdded = { newEvent ->
                    events = events + newEvent
                    showAddEventDialog = false
                }
            )
        }
    }
}
